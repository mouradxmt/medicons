<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASS', '');
  define('DB_NAME', 'centrechu');
  

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://localhost/consultationmedicale');
  // Site Name
  define('SITENAME', 'MEDICONS');

  define('SITELOGO',URLROOT.'/assets/images/logo.png');
  define('SITELOGOLIGHT',URLROOT.'/assets/images/logo-light.png');