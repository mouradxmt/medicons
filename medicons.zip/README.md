![Logo](https://github.com/mouradxmt/medicons/blob/master/public/doc/logo.png)
## About
MEDICONS est une plateforme de consultation médicale , réalisé en premier lieu dans un stage d'initiation au CHU par des étudiants ingénieurs de l'ENSA - Fès en génie Informatique.
## Authors
* MTOUAA Mourad
* RAMDANI Chaimae
* ASSAL Siham
## Technologies
* PHP - MySQL
* Core template (Bootstrap)
* Système MVC
## Screenshots
![Page d'acceuil](https://github.com/mouradxmt/medicons/blob/master/public/doc/docLogged.png)
## Important modifications
* Change contents of app/config/config.php accordignly with the server configuration
* Change Contents of public/.htaccess 
* Upload database sql file "centrechu.sql"
